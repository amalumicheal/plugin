<!doctype html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>ENATTI</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS here -->
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" type="text/css" media="all" />
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slicknav.css" type="text/css" media="all" />
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/style.css" type="text/css" media="all" />
  <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/animate.css" type="text/css" media="all" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BANNER CAROUSEL -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css" type="text/css" media="all" />

   

</head>
<?php wp_head();?>
<body>
    

    <!-- HEADER -->
    <header>
        <div class="header-area">
            <div id="sticky-header" class="main-header-area">
                <div class="container p-0">
                    <div class="row align-items-center no-gutters">
                        <div class="col-xl-4 col-lg-4">
                            <div class="logo-img">
                                <a href="index.html">
                                   <img src="<?php echo get_template_directory_uri().'/images/logo.png';?>" alt="" >


                                </a>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-8">
                            <div class="main-menu  d-none d-lg-block">
                                <nav>
                                    <ul id="navigation">
                                        <li><a class="active"  href="index.html"> home </a></li>
                                        <li><a href="about.html"> About us </a></li>
                                        <li><a href="products.html"> <span> Products </span> </a></li>
                                        <li><a href="gallery.html"> <span> Gallery </span> </a></li>
                                        <li><a href="contact.html"> <span> Contact us </span> </a></li>
                                        <!--
                                        <li><a href="#">pages <i class="ti-angle-down"></i></a>
                                            <ul class="submenu">
                                                <li><a href="#">work details</a></li>
                                                <li><a href="#">elements</a></li>
                                            </ul>
                                        </li>
                                        -->
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER END -->

