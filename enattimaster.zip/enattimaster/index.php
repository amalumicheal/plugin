<?php get_header(); ?>

<?php echo wptuts_slider_template(); ?>

<!-- BANNER CARPUSEL -->
    <section class="car-mt-150">
        <div class="site-section testimonial-wrap custom-owl-carousel" id="testimonials-section">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-5 mr-auto">

                <div class="owl-carousel slide-one-item-alt-text">
                  <div class="slide-text">
                    <blockquote>
                        <h1>Enatti Stainless <br> Water Tanks</h1>
                        <p>Non-toxic and rust free Stainless Water Tanks with UV protection and plastic - free raw materials. </p>
                        <a href="about.html"><button class="read-more">Read More</button></a>
                    </blockquote>
                  </div>
                  <div class="slide-text">
                    <blockquote>
                        <h1>Stainless Steel Water Tank</h1>
                        <p>Our Stainless Steel Water Tanks are manufactured using eco-friendly 304 food-grade steel. Resistance to oxidation and corrosion make Ennati Stainless Steel Water Tank suitable for storing Water and Edible oil. </p>
                        <a href="about.html"><button class="read-more">Read More</button></a>
                    </blockquote>
                  </div>
                </div>

              </div>
              <div class="col-lg-6 ml-auto">
                            
                <div class="owl-carousel slide-one-item-alt">
                 <img src="<?php echo get_template_directory_uri().'/images/banner1.png';?>" alt="Image" class="img-fluid" >
                 <img src="<?php echo get_template_directory_uri().'/images/banner1.png';?>" alt="Image" class="img-fluid" >
                </div>



                <div class="owl-custom-direction">
                  <a href="#" class="custom-prev"><img src="<?php echo get_template_directory_uri().'/images/icon-left.png';?>"></a>

              <a href="#" class="custom-next"><img src="<?php echo get_template_directory_uri().'/images/icon-right.png';?>" ></a>
                </div>

              </div>
            </div>
          </div>
        </div>
    </section>
    <!-- BANNER CARPUSEL END -->

    <div class="bg-blue-banner">
        <img  src="<?php echo get_template_directory_uri().'/images/bg-blue.png';?>"  width="100%">
    </div>
    <div class="bg-blue-banner-dot">
        <img  src="<?php echo get_template_directory_uri().'/images/dot.png';?>"  width="100%">
    </div>

    <div class="clearfix"></div>


    <!-- ABOUT -->
    <section class="m-t-150 m-b-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="about-sec">
                        <img  src="<?php echo get_template_directory_uri().'/images/abt.png';?>"  width="100%">
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                    <div class="about-sec-content">
                        <h5>About Us</h5>
                        <h2>Introducing Our Stainless Steel <br>Water Tank</h2>
                        <p>Enatti Stainless Steel Water Tanks are long-lasting and non-toxic, and we offer 10 years warranty. Our expert team is involved in manufacturing high-quality water tanks with unique specifications understanding the needs of our customers.</p>
                        <a href="about.html"><button class="read-more">Read More</button></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ABOUT END -->

    <!-- OUR PRODUCTS -->
    <section class="m-b-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="about-sec-content">
                        <h5>Our Products</h5>
                        <h2 style="text-transform: uppercase;">Capacities We Offer</h2>
                        <p>Our unique specifications like zero maintenance, easy cleaning and rust-free nature make us a highly competitive dealer of Stainless Steel Water Tanks. Our Products are available in 450L, 500L and 1000L. </p>
                        <!-- tab -->
                        <div class="m-t-20">
                            <div class="tabset">
                              <!-- Tab 1 -->
                              <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked>
                              <label for="tab1">450 L</label>
                              <!-- Tab 2 -->
                              <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
                              <label for="tab2">500 L</label>
                              <!-- Tab 3 -->
                              <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
                              <label for="tab3">1000 L</label>
                              
                              <div class="tab-panels">
                                <section id="marzen" class="tab-panel">
                                  <h3>450 L ENTATTI WATER TANK</h3>
                                  <a href="products.html"><button class="read-more m-r-20">Know More</button></a>
                                  <a href="contact.html"><button class="read-more2">Get a Quote</button></a>
                                </section>
                                <section id="rauchbier" class="tab-panel">
                                  <h3>500 L ENTATTI WATER TANK</h3>
                                  <a href="products.html"><button class="read-more m-r-20">Know More</button></a>
                                  <a href="contact.html"><button class="read-more2">Get a Quote</button></a>
                                </section>
                                <section id="dunkles" class="tab-panel">
                                  <h3>1000 L ENTATTI WATER TANK</h3>
                                  <a href="products.html"><button class="read-more m-r-20">Know More</button></a>
                                  <a href="contact.html"><button class="read-more2">Get a Quote</button></a>
                                </section>
                              </div>
                            </div>
                        </div>
                        <!-- tab - end -->
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                    <div class="pdt-img">
                        <img  src="<?php echo get_template_directory_uri().'/images/pdt.png';?>"   width="100%">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- OUR PRODUCTS END -->


    <!-- BLOG -->
    <section class="m-b-100">
        <div class="container">
            <div class="head-sec text-center">
                <h5>Our Blog</h5>
                <h2>Our Latest Blogs</h2>
            </div>
        </div>
        <div class="container m-t-50">
            <div class="row">
                <div class="col-lg-4 col-md-4 m-t-30 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="zoom-out-img">
                        <img src="<?php echo get_template_directory_uri().'/images/b1.png';?>"/>
                    </div>
                    <div class="blog-grid-bg">
                        <h6>25/09/2020</h6>
                        <h5>Say No To Plastic </h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod elit, sed do eiusmod elit, sed do eiusmod </p>
                        <div class="btn-blog">
                            <button class="read-more3">Know More</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 m-t-30 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="zoom-out-img">
                        <img  src="<?php echo get_template_directory_uri().'/images/b2.png';?>"/>
                    </div>
                    <div class="blog-grid-bg">
                        <h6>25/09/2020</h6>
                        <h5>UV Protection Tanks </h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod elit, sed do eiusmod elit, sed do eiusmod </p>
                        <div class="btn-blog">
                            <button class="read-more3">Know More</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 m-t-30 wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1500ms">
                    <div class="zoom-out-img">
                        <img  src="<?php echo get_template_directory_uri().'/images/b3.png';?>" />
                    </div>
                    <div class="blog-grid-bg">
                        <h6>25/09/2020</h6>
                        <h5>Cleaning the Stainless Tanks </h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod elit, sed do eiusmod elit, sed do eiusmod </p>
                        <div class="btn-blog">
                            <button class="read-more3">Know More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- BLOG END -->


    <!-- TESTIMONIAL CAROUSEL -->
    <section class="car-mt-150 m-b-100">
        <div class="site-section testimonial-wrap custom-owl-carousel" id="testimonials-section">
          <div class="container">
            <div class="clients-head">
                    <h5>Testimonial</h5>
                    <h2>Hear from our clients</h2>
                </div>
            <div class="row align-items-center">
              <div class="col-lg-12 mr-auto">

                <div class="owl-carousel slide-one-item-alt-text2">
                  <div class="slide-text2">
                    <div class="testi-clients">
                        <img src="<?php echo get_template_directory_uri().'/images/client.png';?>" >
                        <h6>John Wick</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod sed do eiusmod</p>
                    </div>
                  </div>
                  <div class="slide-text2">
                    <div class="testi-clients">
                        <img src="<?php echo get_template_directory_uri().'/images/client.png';?>" >
                        <h6>John Wick</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod sed do eiusmod</p>
                    </div>
                  </div>
                  <div class="slide-text2">
                    <div class="testi-clients">
                        <img src="<?php echo get_template_directory_uri().'/images/client.png';?>">
                        <h6>John Wick</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod sed do eiusmod</p>
                    </div>
                  </div>
                  <div class="slide-text2">
                    <div class="testi-clients">
                        <img src="<?php echo get_template_directory_uri().'/images/client.png';?>">
                        <h6>John Wick</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod sed do eiusmod</p>
                    </div>
                  </div>
                </div>

                <div class="owl-custom-direction2">
                  <a href="#" class="custom-prev"><img  src="<?php echo get_template_directory_uri().'/images/icon2-left.png';?>" ></a>
                  <a href="#" class="custom-next"><img  src="<?php echo get_template_directory_uri().'/images/icon2-right.png';?>" ></a>
                </div>

              </div>
            </div>
          </div>
        </div>
    </section>
    <!-- TESTIMONIAL CAROUSEL END -->


<?php get_footer(); ?>