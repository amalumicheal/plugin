
<!-- FOOTER -->
    <section class="bg-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="footer-start">
                        <img src="<?php echo get_template_directory_uri().'/images/logo-footer.png';?>" >
                        <p>Non-toxic and rust free Stainless Water Tanks with UV protection and plastic - free raw materials.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2">
                    <div class="footer-start">
                        <h5>Quick Links</h5>
                        <ul>
                            <a href="index.html"><li>Home</li></a>
                            <a href="about.html"><li>About us</li></a>
                            <a href="products.html"><li>Products</li></a>
                            <a href="gallery.html"><li>Gallery</li></a>
                            <a href="contact.html"><li>Contact us</li></a>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="footer-start">
                        <h5>Contact Info</h5>
                        <p>Enatti Mercantile Concepts Pvt,Ltd. <br>Calicut - 673 571, Kerala</p>
                        <p>+91 8848 18 9071</p>
                        <p>info@enatti.com</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2">
                    <div class="footer-start">
                        <h5>Social Media</h5>
                        <div class="footer-icons">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>  
                    </div>
                </div>
            </div>
            <div class="footer-line"></div>
            <p class="copyright-p">Copyright &#169; 2020.All rights reserved.</p>   
        </div>
    </section>
    <!-- FOOTER END -->


<?php wp_footer();?>

    
    <!-- CALL - MESSAGE -->
    <div class="container-fluid">
        <div class="icon-bar-2">
            <div class="row">
                <div class="col-6 nopad">
                    <button class="call-butn" style="background-color: #097bff"> Call <i class="fa fa-phone"></i></button>
                </div>
                <div class="col-6 nopad">
                    <button class="call-butn" style="background-color: #032348"> Message <i class="fa fa-envelope-o"></i></button>
                </div>
            </div>            
        </div>
    </div>
    <!-- CALL - MESSAGE - END -->







    <!-- JS here -->
   <script src="<?php echo get_template_directory_uri().'/js/jquery-1.12.4.min.js'; ?>" type="text/javascript"></script>

   <script src="<?php echo get_template_directory_uri().'/js/popper.min.js'; ?>" type="text/javascript"></script>

   <script src="<?php echo get_template_directory_uri().'/js/bootstrap.min.js'; ?>" type="text/javascript"></script>


  <script src="<?php echo get_template_directory_uri().'/js/jquery.slicknav.min.js'; ?>" type="text/javascript"></script>


    <!-- HEADER -->
  <script src="<?php echo get_template_directory_uri().'/js/jquery.slicknav.min.js'; ?>" type="text/javascript"></script>

    <!-- BANNER CAROUSEL -->

  <script src="<?php echo get_template_directory_uri().'/js/owl.carousel.min.js'; ?>" type="text/javascript"></script>


   <script src="<?php echo get_template_directory_uri().'/js/aos.js'; ?>" type="text/javascript"></script>
     

  <script src="<?php echo get_template_directory_uri().'/js/carousel-cuztm.js'; ?>" type="text/javascript"></script>

  <script src="<?php echo get_template_directory_uri().'/js/wow.js'; ?>" type="text/javascript"></script>
  

 

</body>
</html>